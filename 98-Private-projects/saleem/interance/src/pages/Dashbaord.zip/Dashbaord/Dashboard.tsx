import React, { useState } from 'react';
import { IntlProvider } from 'react-intl';
import { ProSidebar, SidebarHeader, SidebarFooter, SidebarContent, Menu,MenuItem,SubMenu } from 'react-pro-sidebar';
import 'react-pro-sidebar/dist/css/styles.css';
import './Dashboard.scss'
import Layout from './Layout';
import page1 from './components/DashboardPanel';
import { Routes ,Route } from 'react-router-dom';

const messages:any =  require('./messages.js').default;

console.log(messages.default)

  


function App() {
  const [locale, setLocale] = useState('en');

  return (

    <IntlProvider locale={locale} messages={messages[locale]}>
    <Layout setLocale={setLocale} />
    
    </IntlProvider>)

}

export default App;
