import React from "react";
import { IntlProvider } from "react-intl";
import { Routes } from "react-router-dom";
import Layout from "../Layout";
import messages from '../messages';

interface preferrence {
    lang: number,
    setLang: any,
}

function DashbaorPanel(props:preferrence){
    

}
export default DashbaorPanel;