import react from 'react'


function MainPage()
{
    return (<h1>sdadsa</h1>)
}
export default MainPage;